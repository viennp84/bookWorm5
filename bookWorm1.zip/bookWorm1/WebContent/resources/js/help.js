/**
 * 
 */

function clearInput(elmnt) {
	if(elmnt.value == "Enter Username"){
		elmnt.value = '';
	}if(elmnt.value == "Enter Password"){
		elmnt.value = '';
	}
}

