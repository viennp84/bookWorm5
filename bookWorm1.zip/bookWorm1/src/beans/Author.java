package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/*
 * Vien Nguyen
 * CST235
 *  Author class
 * This class is a model of author.
 */
@ManagedBean
@ViewScoped
public class Author {
	//author id
	int authorId;
	//author name
	@NotNull(message = "Author name is required.")
	@Size(min = 4, max = 50)
	String authorName;
	
	//Default constructor
	public Author() {
	}
	//Default constructor
	public Author(int authorId, String authorName) {
		this.authorId = authorId;
		this.authorName = authorName;
	}
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	

}
