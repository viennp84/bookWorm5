package beans;

import javax.faces.bean.ManagedBean;

import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
/*
 * Jimbo
 * CST235
 * Category class
 * This class is a category model.
 */
@ManagedBean
@ViewScoped
public class Category {
	//category id
	int categoryId;
	//category of the book
	@NotNull(message = "Category is required.")
	@Size(min = 4, max = 30)
	String category;
	//Default constructor
	public Category() {
		// TODO Auto-generated constructor stub
	}
	//Constructor with the parameters
	public Category(int categoryId,
	String category) {
		this.categoryId = categoryId;
		this.category = category;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	
}
