package beans;



import java.util.Date;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
/*
 * Vien Nguyen
 * CST235
 * Category class
 * This class is a Register model.
 */
@ManagedBean
@ViewScoped
public class Register extends User  {
	@NotNull(message = "You have to enter your email!")
	@Size(min = 5, max = 40)
	String email;
	Date createOn;
	Date lastLogin ;
	int userId;
	
	public Register(){
		super();
		email = "TestingEmail@gmail.com";
		createOn = new Date();
		lastLogin = new Date();
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getCreateOn() {
		return createOn;
	}

	public void setCreateOn(Date createOn) {
		this.createOn = createOn;
	}

	public Date getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	
}
