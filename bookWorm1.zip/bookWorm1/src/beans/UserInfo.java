package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

/*
 * Vien Nguyen
 * CST235
 * UserInfo class
 * This class is a UserInfo model. It contains user personal information.
 */
@ManagedBean
@ViewScoped
public class UserInfo {
	//User name
	String username;
	//User first name
	String firstName;
	//User last name
	String lastName;
	//Phone number
	String phoneNumber;
	//User type
	String userType;
	//User email
	String email;
	//Profile picture;
	String profileImage;
	
	//Default constructor
	public UserInfo() {
		
	}
	//Default constructor
	public UserInfo(String username, String firstName, String lastName, String phoneNumber, String userType, String email, String profileImage) {
			this.username = username;
			this.firstName = firstName;
			this.lastName = lastName;
			this.phoneNumber = phoneNumber;
			this.userType = userType;
			this.email = email;
			this.profileImage = profileImage;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}
	
	
	
}
