package data;

import java.util.List;

import javax.ejb.Local;

import beans.Author;

/*
 * Vien Nguyen
 * CST235
 * Data Access Object
 * This is interface that contains the regular methods.
 */
//Methods for CRUD
public interface DataAccessInterface <T> {

	public List<T> findAll();
	public boolean create(T t);
	public boolean update(T t);
	public boolean delete(T t);
}
