package data;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import beans.Author;

/*
 * Jimbo
 * CST235
 * This is the authorDataAccessService implement.
 */

@Stateless
@Local(DataAccessInterface.class)
@LocalBean
@Alternative

public class AuthorDataAccessService implements DataAccessInterface<Author>{
	//Connection details
	Connection conn = null;
	String url = "jdbc:postgresql://localhost:5432/postgres";
	String username = "postgres";
	String password = "Chihaiis02";
	
	//Get all author list
	@Override
	public List<Author> findAll() {
		String sql = "Select * FROM  bookworm.author";
		List<Author> authors = new  ArrayList<Author>();
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			// Execute SQL Query and loop over result set.
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
				while (rs.next()) {
					authors.add(new Author(rs.getInt("AUTHOR_ID"), rs.getString("AUTHOR_NAME")));
				}
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return authors;
	}
	//Create a new author into the database
	@Override
	public boolean create(Author author) {
		boolean isCreated = false;
		String sql = "INSERT INTO bookworm.author(AUTHOR_NAME) VALUES(?)";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, author.getAuthorName());
			st.executeUpdate();
			conn.close();
			isCreated = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isCreated;
	}
	//Update exist author
	@Override
	public boolean update(Author author) {
		boolean isUpdated = false;
		String sql = "UPDATE bookworm.author set AUTHOR_NAME = ? WHERE AUTHOR_ID =?";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, author.getAuthorName());
			st.setInt(2, author.getAuthorId());
			st.executeUpdate();
			conn.close();
			isUpdated = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isUpdated;
	}
	//Delete author from the database
	@Override
	public boolean delete(Author author) {
		boolean isDeleted = false;
		String sql = "DELETE FROM bookworm.author WHERE AUTHOR_ID =?";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			PreparedStatement st = conn.prepareStatement(sql);
			st.setInt(1, author.getAuthorId());
			st.executeUpdate();
			conn.close();
			isDeleted = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isDeleted;
	}

}
