package data;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import beans.Book;

/*
 * Vien Nguyen
 * CST235
 * This is the BookDataAccessService implement.
 */

@Stateless
@Local(DataAccessInterface.class)
@LocalBean
@Alternative

@ManagedBean
@ViewScoped
public class BookDataAccessService implements DataAccessInterface<Book> {
	//Connection details
	Connection conn = null;
	String url = "jdbc:postgresql://localhost:5432/postgres";
	String username = "postgres";
	String password = "Chihaiis02";
	
	//Get the book list
	@Override
	public List<Book> findAll() {
		List<Book> books = new ArrayList<Book>();
		
		String sql = "Select * FROM bookworm.book";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			// Execute SQL Query and loop over result set.
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
				while (rs.next()) {
					books.add(new Book(rs.getInt("BOOK_ID"), rs.getString("TITLE"), rs.getString("ISBN"),
							rs.getInt("AUTHOR_ID"), rs.getString("PUBLISHER"), rs.getInt("EDITION"),
							rs.getString("TYPE"), rs.getInt("CATEGORY_ID"), rs.getString("COVER_IMAGE")));
				}
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return books;
	}
	//Create the new book
	@Override
	public boolean create(Book book) {
		// checking if a book is inserted.
				boolean isCreated = false;
				String sql = "INSERT INTO bookworm.book(TITLE, ISBN, AUTHOR_ID, PUBLISHER, EDITION, TYPE, CATEGORY_ID, COVER_IMAGE) VALUES(?,?,?,?,?,?,?,?)";
				try {
					// Connect to the Database
					conn = DriverManager.getConnection(url, username, password);
					PreparedStatement st = conn.prepareStatement(sql);
					st.setString(1, book.getTitle());
					st.setString(2, book.getIsbn());
					st.setInt(3, book.getAuthorId());
					st.setString(4, book.getPublisher());
					st.setInt(5, book.getEdition());
					st.setString(6, book.getType());
					st.setInt(7, book.getCategoryId());
					st.setString(8, book.getCoverImage());
					st.executeUpdate();
					conn.close();
					isCreated = true;

				} catch (SQLException e) {
					e.printStackTrace();
				}
				return isCreated;
	}
	//Update the book
	@Override
	public boolean update(Book book) {
		boolean isUpdated = false;
		String sql = "UPDATE bookworm.book set TITLE = ?, ISBN = ?, AUTHOR_ID = ?, PUBLISHER = ?, EDITION = ?, TYPE = ?, CATEGORY_ID = ?, COVER_IMAGE = ?  WHERE BOOK_ID =?";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, book.getTitle());
			st.setString(2, book.getIsbn());
			st.setInt(3, book.getAuthorId());
			st.setString(4, book.getPublisher());
			st.setInt(5, book.getEdition());
			st.setString(6, book.getType());
			st.setInt(7, book.getCategoryId());
			st.setString(8, book.getCoverImage());
			st.setInt(9, book.getBookId());
			st.executeUpdate();
			conn.close();
			isUpdated = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isUpdated;
	}
	//Delete book from the database
	@Override
	public boolean delete(Book book) {
		boolean isDeleted = false;
		String sql = "DELETE FROM bookworm.book WHERE BOOK_ID =?";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			PreparedStatement st = conn.prepareStatement(sql);
			st.setInt(1, book.getBookId());
			st.executeUpdate();
			System.out.println(st.executeUpdate());
			conn.close();
			isDeleted = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isDeleted;
	}

}
