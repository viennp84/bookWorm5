package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import beans.Category;

/*
 * Jimbo
 * CST235
 * This is the CategoryDataAccessService implement.
 */

@Stateless
@Local(DataAccessInterface.class)
@LocalBean
@Alternative

public class CategoryDataAccessService implements DataAccessInterface<Category>{
	//Connection details
	Connection conn = null;
	String url = "jdbc:postgresql://localhost:5432/postgres";
	String username = "postgres";
	String password = "Chihaiis02";
	
	//Get all the category list
	@Override
	public List<Category> findAll() {
		String sql = "Select * FROM  bookworm.category";
		List<Category> categories = new  ArrayList<Category>();
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			// Execute SQL Query and loop over result set.
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
				while (rs.next()) {
					categories.add(new Category(rs.getInt("CATEGORY_ID"), rs.getString("CATEGORY")));
				}
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return categories;
	}
	//Create a new category
	@Override
	public boolean create(Category category) {
		boolean isCreated = false;
		Connection conn = null;
		String sql = "INSERT INTO bookworm.category(CATEGORY) VALUES(?)";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, category.getCategory());
			st.executeUpdate();
			conn.close();
			isCreated = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isCreated;
	}
	//Update category
	@Override
	public boolean update(Category category) {
		boolean isUpdated = false;
		Connection conn = null;
		String sql = "UPDATE bookworm.category set CATEGORY = ? WHERE CATEGORY_ID =?";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			PreparedStatement st = conn.prepareStatement(sql);
			st.setString(1, category.getCategory());
			st.setInt(2, category.getCategoryId());
			st.executeUpdate();
			conn.close();
			isUpdated = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isUpdated;
	}
	
	//Delete category from the database
	@Override
	public boolean delete(Category category) {
		Connection conn = null;
		boolean isDeleted = false;
		String sql = "DELETE FROM bookworm.Category WHERE CATEGORY_ID =?";
		try {
			// Connect to the Database
			conn = DriverManager.getConnection(url, username, password);
			PreparedStatement st = conn.prepareStatement(sql);
			st.setInt(1, category.getCategoryId());
			st.executeUpdate();
			conn.close();
			isDeleted = true;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isDeleted;
	}

	

}
