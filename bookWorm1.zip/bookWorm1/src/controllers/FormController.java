package controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;

import beans.Author;
import beans.Book;
import beans.Category;
import beans.User;
import data.DataAccessInterface;
import data.UserDataAccessService;

/*
 * Vien Nguyen
 * CST235, Controller class
 * This class will receive requests and redirect the processing.
 */

@ManagedBean
@ViewScoped
public class FormController {
	// Call the author business interface and its implements.
	@Inject
	DataAccessInterface<Author> authorService;
	// Call the category business interface and its implements.
	@Inject
	DataAccessInterface<Category> categoryService;
	// Call the user business interface and its implements.
	@Inject
	DataAccessInterface<User> userService;
	// Call the book business interface and its implements.
	@Inject
	DataAccessInterface<Book> BookService;

	public DataAccessInterface<Author> getAuthorService() {
		return authorService;
	}

	public DataAccessInterface<Category> getCategoryService() {
		return categoryService;
	}

	public DataAccessInterface<User> getUserService() {
		return userService;
	}

	public String onSubmit(User user) {
		UserDataAccessService u = new UserDataAccessService();

		boolean login = u.login(user);
		if (login) {
			return "index.xhtml";
		} else {
			return "layouts/commonContent.xhtml";
		}
	}

	public DataAccessInterface<Book> getBookService() {
		return BookService;
	}
	
	
}
